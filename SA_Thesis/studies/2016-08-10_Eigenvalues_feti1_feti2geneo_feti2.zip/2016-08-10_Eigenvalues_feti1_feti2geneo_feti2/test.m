femacdir = '../../FEMAC/'
addpath(femacdir)


prob=femac